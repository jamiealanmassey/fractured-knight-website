# For the Hack:
We have a small list of Scenes that need to be created for the hack. They are the following:

## Main Scene - last thing to do
Here we need the main scene where we will attach all the worlds. For our case just the first one but we will need to have a few "to-be-made" worlds that we can later add.   

## Player - Jamie
Has movement, collision and animations. There should be a blank journal when you click on the player.
For the inventory system I say we don't include that for now but instead do that for the next version.

## World - Nathan / Vikram
1 world, 5 rooms. Each room will have its own scene therefore 5 scenes are required. Atrifacts, 3 items to be scatteded accorss the 5 rooms. Each room must be different. 
world -> room -> items
Items: these can be anything like artifacts.

I suggest we get started on the game as soon as possible and not be scared to ask for help.  
Also **unit Tests** will need to be completed and logged (more on that later).

**Good luck!**

PS: more will come soon.....
